module SurvivalModeConfig

end